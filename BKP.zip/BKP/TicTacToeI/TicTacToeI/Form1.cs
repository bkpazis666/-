﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TicTacToeI
{
    public partial class Form1 : Form
    {
        private char currentPlayer;
        private char[,] board;

        public Form1()
        {
            InitializeComponent();
            currentPlayer = 'X';
            board = new char[3, 3];
            InitializeBoard();
        }

        private void InitializeBoard()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    board[i, j] = ' ';
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            int index = int.Parse(clickedButton.Name.Substring(6)) - 1; // Extracts index from name
            int row = index / 3;
            int col = index % 3;

            if (board[row, col] == ' ')
            {
                board[row, col] = currentPlayer;
                clickedButton.Text = currentPlayer.ToString();

                if (CheckWinner())
                {
                    MessageBox.Show("Player " + currentPlayer + " wins!");
                    SaveGameResult(currentPlayer);
                    InitializeBoard();
                    ResetButtons();
                }
                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        private bool CheckWinner()
        {
            for (int i = 0; i < 3; i++)
            {
                if ((board[i, 0] == currentPlayer && board[i, 1] == currentPlayer && board[i, 2] == currentPlayer) ||
                    (board[0, i] == currentPlayer && board[1, i] == currentPlayer && board[2, i] == currentPlayer))
                    return true;
            }
            if ((board[0, 0] == currentPlayer && board[1, 1] == currentPlayer && board[2, 2] == currentPlayer) ||
                (board[0, 2] == currentPlayer && board[1, 1] == currentPlayer && board[2, 0] == currentPlayer))
                return true;

            return false;
        }

        private void ResetButtons()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                    control.Text = "";
            }
        }

        private void SaveGameResult(char winner)
        {
            using (SqlConnection connection = new SqlConnection("Server=myServerAddress;Database=myDataBase;Integrated Security=True;"))
            {
                connection.Open();
                string query = "INSERT INTO results (PlayerX, PlayerO, Winner, GameDate) VALUES (@PlayerX, @PlayerO, @Winner, @GameDate)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlayerX", "Player X");
                command.Parameters.AddWithValue("@PlayerO", "Player O");
                command.Parameters.AddWithValue("@Winner", winner);
                command.Parameters.AddWithValue("@GameDate", DateTime.Now);
                command.ExecuteNonQuery();
            }
        }

        // Event handlers for buttons
        private void button1_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button2_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button3_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button4_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button5_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button6_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button7_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button8_Click(object sender, EventArgs e) { Button_Click(sender, e); }
        private void button9_Click(object sender, EventArgs e) { Button_Click(sender, e); }
    }
}
