﻿using System;
using System.Data.SqlClient;

class TicTacToe
{
    private char[,] board = new char[3, 3];
    private char currentPlayer;

    public TicTacToe()
    {
        currentPlayer = 'X'; // Player X starts first
        InitializeBoard();
    }

    private void InitializeBoard()
    {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                board[i, j] = ' ';
    }

    public void PlayGame()
    {
        while (true)
        {
            PrintBoard();
            Console.WriteLine($"Player {currentPlayer}, choose row (0-2) and column (0-2), separated by a comma:");
            var input = Console.ReadLine().Split(',');
            int row = int.Parse(input[0]);
            int col = int.Parse(input[1]);

            if (board[row, col] == ' ')
            {
                board[row, col] = currentPlayer;

                if (CheckWinner())
                {
                    PrintBoard();
                    Console.WriteLine($"Player {currentPlayer} wins!");
                    SaveGameResult(currentPlayer);
                    break;
                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
            else
            {
                Console.WriteLine("This cell is already taken. Try again.");
            }
        }
    }

    private void PrintBoard()
    {
        Console.Clear();
        Console.WriteLine(" Game Board ");
        Console.WriteLine("  0   1   2");
        for (int i = 0; i < 3; i++)
        {
            Console.Write(i + " ");
            for (int j = 0; j < 3; j++)
            {
                Console.Write($" {board[i, j]} ");
                if (j < 2) Console.Write("|");
            }
            Console.WriteLine();
            if (i < 2) Console.WriteLine(" ---+---+--- ");
        }
        Console.WriteLine();
    }

    private bool CheckWinner()
    {
        for (int i = 0; i < 3; i++)
        {
            if ((board[i, 0] == currentPlayer && board[i, 1] == currentPlayer && board[i, 2] == currentPlayer) ||
                (board[0, i] == currentPlayer && board[1, i] == currentPlayer && board[2, i] == currentPlayer))
                return true;
        }
        if ((board[0, 0] == currentPlayer && board[1, 1] == currentPlayer && board[2, 2] == currentPlayer) ||
            (board[0, 2] == currentPlayer && board[1, 1] == currentPlayer && board[2, 0] == currentPlayer))
            return true;

        return false;
    }

    private void SaveGameResult(char winner)
    {
        using (SqlConnection connection = new SqlConnection("Server=myServerAddress;Database=myDataBase;Integrated Security=True;"))
        {
            connection.Open();
            string query = "INSERT INTO results (PlayerX, PlayerO, Winner, GameDate) VALUES (@PlayerX, @PlayerO, @Winner, @GameDate)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@PlayerX", "Player X");
            command.Parameters.AddWithValue("@PlayerO", "Player O");
            command.Parameters.AddWithValue("@Winner", winner);
            command.Parameters.AddWithValue("@GameDate", DateTime.Now);
            command.ExecuteNonQuery();
        }
    }

    static void Main(string[] args)
    {
        TicTacToe game = new TicTacToe();
        game.PlayGame();
    }
}
