CREATE TABLE results (
    Id INT PRIMARY KEY IDENTITY,
    PlayerX VARCHAR(50),
    PlayerO VARCHAR(50),
    Winner CHAR(1),
    GameDate DATETIME
);
